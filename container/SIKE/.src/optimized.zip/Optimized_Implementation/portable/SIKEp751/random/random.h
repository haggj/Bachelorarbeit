#ifndef RANDOM_H
#define RANDOM_H


// Generate random bytes and output the result to random_array
int randombytes(unsigned char* random_array, unsigned long long nbytes);


#endif